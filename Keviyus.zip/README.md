# Keviyus v1.0

Jewish calendar app

Michoel Reach, 12/06/2018 (29 Cheshvan 5779)

This app is designed to teach the full process of calculating the Jewish calendar for a full year,
starting with the number of the year.

To use it, download the zip folder, check for viruses, and unzip.
Along with supporting files, the folder contains two PowerPoint presentations/pdfs and two html pages.

The main presentation is This year's calendar. It walks through the process of creating a calendar
in detail, from beginning to end.

The two html pages are tools to aid that presentation.
One is Calculator, for calculating the molad.
The second is Keviyus.htm, which is a web page equivalent of the 14 keviyuyos chart in the Tur,
Orach Chaim 428. It shows every detail of the 14 different Jewish calendars, along with some
convenient aids to visualization.

The last presentation is The keviyus page, which describes some of the features of the Keviyus page.